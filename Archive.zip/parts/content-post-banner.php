<div class="banner page-banner<?php if(is_single()):?> post-banner<?php endif;?> has-bg">
	<?php get_template_part('parts/content', 'post-banner-bg-img');?>
	<div class="bg banner-gradient"></div>
	<div class="white-accent-wrap">
		<div class="grid-container">
			<div class="grid-x grid-padding-x">
				<div class="cell small-12 medium-10 large-9 large-offset-1">
					<div class="white-accent"></div>
				</div>
			</div>
		</div>
	</div>
</div>